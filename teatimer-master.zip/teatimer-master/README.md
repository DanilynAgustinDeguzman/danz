# TeaTimer
A Tea Timer build with ReactJS. http://kevingimbel.com/teatimer

While learning ReactJS I thought it's a good idea to finally build a simple TeaTimer. You can use the Tea Timer at http://kevingimbel.com/teatimer, currently there are only three teas available and no option to add new teas.

!["Tea Timer v0.0.1 usage"](https://raw.githubusercontent.com/kevingimbel/teatimer/master/tea.gif)
